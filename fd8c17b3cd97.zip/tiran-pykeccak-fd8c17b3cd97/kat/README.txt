Source: http://keccak.noekeon.org/KeccakKAT-3.zip
 
